import { PassengerName.Validator } from './passenger-name.validator';

describe('PassengerName.Validator', () => {
  it('should create an instance', () => {
    expect(new PassengerName.Validator()).toBeTruthy();
  });
});
