import { FlightBooking } from './../shared/FlightBooking';
import { PassengerNameValidator } from './passenger-name.validator';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup
} from '@angular/forms';
import { BookFlightService } from './book-flight.service';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';



@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {
  errorMessage: String;
  successMessage: String;

  constructor(
    private fb: FormBuilder,
    private bookFlightService: BookFlightService
  ) { }

  bookingForm = this.fb.group({
    passengerName: ["", Validators.required],
    noOfTickets: ["", [Validators.required, Validators.min(1)]],
    flightId: ["", [Validators.required, validateFlight]]
  });

ngOnInit() {
}

  book() {
    this.successMessage = null;
    this.errorMessage = null;
    console.log(JSON.stringify(this.bookingForm.value));
    this.bookFlightService.getData(this.bookingForm.value).subscribe(
      response => {
        this.successMessage = response.message;
        console.log("Success"+ this.successMessage);
      }
      ,
      err =>
        this.errorMessage = err.error.message );
  }
}
  function validateFlight(c: FormControl) {
    const FLIGHT_REGEX = /^[A-Z]{3}-[0-9]{3}$/;

    var val: string = c.value;
    console.log(c.value);
    console.log('Regex ' + val.match(/[A-Z][A-Z][A-Z]-{0-9][0-9][0-9]/));
      return FLIGHT_REGEX.test(c.value) ? null : {
        flightError: {
          message: 'Invalid flightID'
        }
      };
  }
  // must be invoked when the Book Flight button is clicked and necessary operations must be performed.
  // invoke getData() of book flight service.ts and handle hte success and error messages.
  // all validation messsages must be displayed if the original data of the field was modified
